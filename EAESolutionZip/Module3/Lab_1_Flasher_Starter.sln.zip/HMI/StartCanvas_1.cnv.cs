/*
 * Created by HMI.Main.
 * User: kovaivo
 * Date: 18.09.2008
 * Time: 17:49
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;

using NxtControl.GuiFramework;
using NxtControl.Services;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of StartCanvas.
	/// </summary>
	public partial class StartCanvas_1 : NxtControl.GuiFramework.StartCanvas
	{
		public StartCanvas_1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
