using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region RadioBool_HMI;
#endregion RadioBool_HMI;

#endregion Definitions;

