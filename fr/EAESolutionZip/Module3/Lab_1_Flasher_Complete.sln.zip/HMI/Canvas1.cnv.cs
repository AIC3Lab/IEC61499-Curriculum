﻿/*
 * Created by EcoStruxure Automation Expert.
 * User: Pranay Jhunjhunwala
 * Date: 28/10/2022
 * Time: 2:52 pm
 * 
 */

using System;
using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas1.
	/// </summary>
	public partial class Canvas1 : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
